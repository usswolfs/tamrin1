# Backend CRUD API

پروژه REST API با Laravel 11 و Sanctum بر اساس موارد قابل‌خواندن از عکس تخته و الگوی PHP/Laravel مخزن عمومی Hojjat Fazayeli ساخته شده است.

## امکانات
- CRUD برای محصولات (به‌عنوان موجودیت نمونه)، کاربران و سفارش‌ها
- احراز هویت Token با Laravel Sanctum: ثبت‌نام، ورود، خروج و پروفایل
- اعتبارسنجی ورودی در تمام endpointهای نوشتن
- پاسخ‌های استاندارد با API Resource و صفحه‌بندی
- دسترسی مدیریت برای CRUD کاربران؛ کاربر عادی فقط سفارش‌های خودش را می‌بیند
- کنترل موجودی محصول هنگام ثبت سفارش و بازگرداندن موجودی هنگام حذف سفارش
- مجموعه Postman در `postman/Backend-CRUD-API.postman_collection.json`

## پیش‌نیاز
PHP 8.2+، Composer و افزونه‌های معمول Laravel برای SQLite یا MySQL.

## نصب و اجرا
```bash
composer install
cp .env.example .env
php artisan key:generate
# برای SQLite:
touch database/database.sqlite
# سپس در .env مقدار DB_CONNECTION=sqlite باشد.
php artisan migrate --seed
php artisan serve
```
آدرس پایه: `http://127.0.0.1:8000/api/v1`

## حساب‌های آزمایشی
- مدیر: `admin@example.com` / `Password123!`
- کاربر: `user@example.com` / `Password123!`

پس از ورود، مقدار `token` را در Postman به‌عنوان Bearer Token قرار دهید. رمزهای بالا فقط برای محیط توسعه هستند؛ در محیط واقعی حتماً تغییر دهید.

## مسیرها
| Method | Endpoint | دسترسی |
|---|---|---|
| POST | `/register` | عمومی |
| POST | `/login` | عمومی |
| GET | `/me` | توکن‌دار |
| POST | `/logout` | توکن‌دار |
| GET, POST | `/products` | توکن‌دار |
| GET, PUT/PATCH, DELETE | `/products/{id}` | توکن‌دار |
| GET, POST | `/users` | مدیر |
| GET, PUT/PATCH, DELETE | `/users/{id}` | مدیر |
| GET, POST | `/orders` | توکن‌دار |
| GET, PUT/PATCH, DELETE | `/orders/{id}` | توکن‌دار؛ ویرایش/حذف مدیر |

## نمونه درخواست
```http
POST /api/v1/orders
Authorization: Bearer YOUR_TOKEN
Content-Type: application/json

{"product_id":1,"quantity":2,"notes":"اولین سفارش"}
```

## تست
```bash
php artisan test
```
نکته: این فایل ZIP شامل سورس پروژه است و `vendor/` را برای کم‌حجم ماندن شامل نمی‌شود؛ بعد از استخراج، `composer install` را اجرا کنید.
