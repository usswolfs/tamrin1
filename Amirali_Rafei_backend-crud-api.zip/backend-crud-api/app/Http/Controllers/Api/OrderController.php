<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Http\Resources\OrderResource;
use App\Models\Order;
use App\Models\Product;
use Illuminate\Http\Request;
class OrderController extends Controller
{
    public function index(Request $request)
    {
        $query = Order::with(['user','product'])->latest();
        if (!$request->user()->isAdmin()) $query->where('user_id', $request->user()->id);
        return OrderResource::collection($query->paginate(15));
    }
    public function store(Request $request)
    {
        $data = $request->validate([
            'product_id' => ['required','integer','exists:products,id'],
            'quantity' => ['required','integer','min:1','max:10000'],
            'notes' => ['nullable','string','max:2000'],
        ]);
        $product = Product::findOrFail($data['product_id']);
        if ($product->stock < $data['quantity']) return response()->json(['message' => 'موجودی محصول کافی نیست.'], 422);
        $order = Order::create([
            'user_id' => $request->user()->id, 'product_id' => $product->id,
            'quantity' => $data['quantity'], 'unit_price' => $product->price,
            'status' => 'pending', 'notes' => $data['notes'] ?? null,
        ]);
        $product->decrement('stock', $data['quantity']);
        return (new OrderResource($order->load(['user','product'])))->response()->setStatusCode(201);
    }
    public function show(Request $request, Order $order)
    {
        abort_unless($request->user()->isAdmin() || $order->user_id === $request->user()->id, 403);
        return new OrderResource($order->load(['user','product']));
    }
    public function update(Request $request, Order $order)
    {
        abort_unless($request->user()->isAdmin(), 403);
        $data = $request->validate(['status' => ['sometimes','required','in:pending,paid,shipped,cancelled'], 'notes' => ['sometimes','nullable','string','max:2000']]);
        $order->update($data);
        return new OrderResource($order->refresh()->load(['user','product']));
    }
    public function destroy(Request $request, Order $order)
    {
        abort_unless($request->user()->isAdmin(), 403);
        if ($order->status !== 'cancelled') {
            $order->product()->increment('stock', $order->quantity);
        }
        $order->delete();
        return response()->json(null, 204);
    }
}
