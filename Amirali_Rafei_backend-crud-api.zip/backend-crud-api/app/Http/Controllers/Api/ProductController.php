<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Http\Resources\ProductResource;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
class ProductController extends Controller
{
    public function index() { return ProductResource::collection(Product::query()->latest()->paginate(15)); }
    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required','string','max:150'], 'sku' => ['required','string','max:80','unique:products,sku'],
            'description' => ['nullable','string','max:5000'], 'price' => ['required','numeric','min:0'],
            'stock' => ['required','integer','min:0'],
        ]);
        return (new ProductResource(Product::create($data)))->response()->setStatusCode(201);
    }
    public function show(Product $product) { return new ProductResource($product); }
    public function update(Request $request, Product $product)
    {
        $data = $request->validate([
            'name' => ['sometimes','required','string','max:150'],
            'sku' => ['sometimes','required','string','max:80',Rule::unique('products','sku')->ignore($product->id)],
            'description' => ['sometimes','nullable','string','max:5000'],
            'price' => ['sometimes','required','numeric','min:0'], 'stock' => ['sometimes','required','integer','min:0'],
        ]);
        $product->update($data);
        return new ProductResource($product->refresh());
    }
    public function destroy(Product $product)
    {
        if ($product->orders()->exists()) return response()->json(['message' => 'محصول دارای سفارش است و حذف نمی‌شود.'], 409);
        $product->delete();
        return response()->json(null, 204);
    }
}
