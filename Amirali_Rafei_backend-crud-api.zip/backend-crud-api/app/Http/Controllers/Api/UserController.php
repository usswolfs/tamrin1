<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
class UserController extends Controller
{
    public function index() { return UserResource::collection(User::query()->latest()->paginate(15)); }
    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required','string','max:120'], 'email' => ['required','email','max:255','unique:users,email'],
            'password' => ['required','string','min:8'], 'role' => ['sometimes',Rule::in(['user','admin'])],
        ]);
        $user = User::create($data + ['role' => 'user']);
        return (new UserResource($user))->response()->setStatusCode(201);
    }
    public function show(User $user) { return new UserResource($user); }
    public function update(Request $request, User $user)
    {
        $data = $request->validate([
            'name' => ['sometimes','required','string','max:120'],
            'email' => ['sometimes','required','email','max:255',Rule::unique('users','email')->ignore($user->id)],
            'password' => ['sometimes','required','string','min:8'],
            'role' => ['sometimes','required',Rule::in(['user','admin'])],
        ]);
        $user->update($data);
        return new UserResource($user->refresh());
    }
    public function destroy(User $user)
    {
        if ($user->orders()->exists()) return response()->json(['message' => 'کاربر دارای سفارش است و حذف نمی‌شود.'], 409);
        $user->delete();
        return response()->json(null, 204);
    }
}
