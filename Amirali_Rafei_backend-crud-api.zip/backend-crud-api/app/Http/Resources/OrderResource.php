<?php
namespace App\Http\Resources;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
class OrderResource extends JsonResource
{
    public function toArray(Request $request): array {
        return ['id'=>$this->id,'user'=>new UserResource($this->whenLoaded('user')),'product'=>new ProductResource($this->whenLoaded('product')),'quantity'=>$this->quantity,'unit_price'=>$this->unit_price,'status'=>$this->status,'notes'=>$this->notes,'created_at'=>$this->created_at];
    }
}
