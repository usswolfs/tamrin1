<?php
namespace Database\Seeders;
use App\Models\Product;
use App\Models\User;
use Illuminate\Database\Seeder;
class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        User::updateOrCreate(['email'=>'admin@example.com'], ['name'=>'API Admin','password'=>'Password123!','role'=>'admin']);
        User::updateOrCreate(['email'=>'user@example.com'], ['name'=>'Demo User','password'=>'Password123!','role'=>'user']);
        Product::firstOrCreate(['sku'=>'DEMO-001'], ['name'=>'Sample Product','description'=>'محصول نمونه برای تست API','price'=>125000,'stock'=>25]);
    }
}
