<?php
use Illuminate\Support\Facades\Artisan;
Artisan::command('about-project', function () { $this->comment('Backend CRUD API'); });
