<?php
namespace Tests\Feature;
use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
class ApiSmokeTest extends TestCase
{
    use RefreshDatabase;
    public function test_registration_returns_a_token(): void
    {
        $response = $this->postJson('/api/v1/register', [
            'name'=>'Test User','email'=>'test@example.com','password'=>'Password123!','password_confirmation'=>'Password123!'
        ]);
        $response->assertCreated()->assertJsonStructure(['user'=>['id','email'],'token']);
    }
    public function test_registration_validates_required_fields(): void
    {
        $this->postJson('/api/v1/register', [])->assertUnprocessable()->assertJsonValidationErrors(['name','email','password']);
    }
}
