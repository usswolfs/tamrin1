# Backend CRUD API

پروژه REST API با Laravel 11 برای مدیریت محصولات، کاربران و سفارش‌ها.

## قابلیت‌ها
- احراز هویت Token-based با Laravel Sanctum
- CRUD محصولات
- CRUD کاربران (فقط مدیر)
- CRUD سفارش‌ها
- اعتبارسنجی ورودی‌ها با Form Request
- خروجی استاندارد با API Resource
- کنترل دسترسی و مالکیت سفارش‌ها
- تراکنش دیتابیس هنگام ثبت سفارش و کاهش موجودی
- مجموعه درخواست‌های Postman در `postman/Backend-CRUD-API.postman_collection.json`

## پیش‌نیاز
- PHP 8.2+
- Composer
- MySQL یا SQLite
- افزونه‌های معمول PHP موردنیاز Laravel

## نصب
```bash
composer install
cp .env.example .env
php artisan key:generate
php artisan migrate --seed
php artisan serve
```
در ویندوز PowerShell:
```powershell
Copy-Item .env.example .env
```
برای استفاده از SQLite، فایل `database/database.sqlite` را بسازید و در `.env` مقدار `DB_CONNECTION=sqlite` قرار دهید.

## حساب آزمایشی
پس از اجرای seeder:
- Email: `admin@example.com`
- Password: `Password123!`

## احراز هویت
درخواست `POST /api/register` یا `POST /api/login` توکن برمی‌گرداند. برای مسیرهای محافظت‌شده هدر زیر را ارسال کنید:
```http
Authorization: Bearer YOUR_TOKEN
Accept: application/json
```

## مسیرهای API
| Method | Endpoint | توضیح |
|---|---|---|
| POST | `/api/register` | ثبت‌نام |
| POST | `/api/login` | ورود و دریافت توکن |
| POST | `/api/logout` | ابطال توکن جاری |
| GET | `/api/me` | کاربر جاری |
| GET/POST | `/api/products` | فهرست / ایجاد محصول |
| GET/PUT/DELETE | `/api/products/{product}` | نمایش / ویرایش / حذف |
| GET | `/api/users` | فهرست کاربران (مدیر) |
| POST | `/api/users` | ایجاد کاربر (مدیر) |
| GET/PUT/DELETE | `/api/users/{user}` | مدیریت کاربر (مدیر) |
| GET/POST | `/api/orders` | سفارش‌های کاربر / ایجاد سفارش |
| GET/PUT/DELETE | `/api/orders/{order}` | نمایش / تغییر وضعیت / حذف سفارش |

## نکات طراحی
- `FormRequest` برای اعتبارسنجی درخواست‌ها استفاده شده است.
- `JsonResource` برای تخصیص و قالب‌بندی خروجی API استفاده شده است.
- فقط مدیر اجازه مدیریت کاربران و حذف/ویرایش محصولات را دارد.
- کاربر عادی فقط سفارش‌های خودش را مشاهده می‌کند.
- ایجاد سفارش در تراکنش انجام می‌شود تا موجودی محصول به‌صورت اتمیک کم شود.

## تست
```bash
php artisan test
```

این مخزن یک اسکلت منبع Laravel است؛ پوشه `vendor` عمداً داخل ZIP قرار نگرفته و با `composer install` ساخته می‌شود.
