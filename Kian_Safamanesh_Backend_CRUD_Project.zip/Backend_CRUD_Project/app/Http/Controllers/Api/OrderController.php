<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\OrderRequest;
use App\Http\Resources\OrderResource;
use App\Models\Order;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class OrderController extends Controller
{
    public function index(Request $request): AnonymousResourceCollection
    {
        $query = Order::with('items.product')->latest();
        if ($request->user()->role !== 'admin') {
            $query->where('user_id', $request->user()->id);
        }
        return OrderResource::collection($query->paginate(15));
    }

    public function store(OrderRequest $request): OrderResource
    {
        $order = DB::transaction(function () use ($request) {
            $order = Order::create(['user_id' => $request->user()->id, 'status' => 'pending', 'total' => 0]);
            $total = 0;

            foreach ($request->validated('items') as $item) {
                $product = Product::whereKey($item['product_id'])->lockForUpdate()->firstOrFail();
                if (!$product->is_active || $product->stock < $item['quantity']) {
                    throw ValidationException::withMessages([
                        'items' => ["موجودی محصول {$product->name} کافی نیست."]
                    ]);
                }
                $product->decrement('stock', $item['quantity']);
                $line = $product->price * $item['quantity'];
                $total += $line;
                $order->items()->create([
                    'product_id' => $product->id,
                    'quantity' => $item['quantity'],
                    'unit_price' => $product->price,
                ]);
            }
            $order->update(['total' => $total]);
            return $order->load('items.product');
        });

        return new OrderResource($order);
    }

    public function show(Request $request, Order $order): OrderResource
    {
        abort_unless($request->user()->role === 'admin' || $order->user_id === $request->user()->id, 403);
        return new OrderResource($order->load('items.product'));
    }

    public function update(OrderRequest $request, Order $order): OrderResource
    {
        abort_unless($request->user()->role === 'admin', 403);
        $order->update(['status' => $request->validated('status')]);
        return new OrderResource($order->load('items.product'));
    }

    public function destroy(Request $request, Order $order): Response
    {
        abort_unless($request->user()->role === 'admin', 403);
        DB::transaction(function () use ($order) {
            if ($order->status === 'pending') {
                foreach ($order->items as $item) {
                    Product::whereKey($item->product_id)->increment('stock', $item->quantity);
                }
            }
            $order->delete();
        });
        return response()->noContent();
    }
}
