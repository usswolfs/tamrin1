<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\AdminUserRequest;
use App\Http\Resources\UserResource;
use App\Models\User;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Http\Response;

class UserController extends Controller
{
    public function index(): AnonymousResourceCollection
    {
        return UserResource::collection(User::latest()->paginate(15));
    }

    public function store(AdminUserRequest $request): UserResource
    {
        return new UserResource(User::create($request->validated()));
    }

    public function show(User $user): UserResource
    {
        return new UserResource($user);
    }

    public function update(AdminUserRequest $request, User $user): UserResource
    {
        $data = $request->validated();
        if (empty($data['password'])) unset($data['password']);
        $user->update($data);
        return new UserResource($user->refresh());
    }

    public function destroy(User $user): Response
    {
        abort_if($user->id === auth()->id(), 422, 'امکان حذف حساب خودتان وجود ندارد.');
        $user->delete();
        return response()->noContent();
    }
}
