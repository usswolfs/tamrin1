<?php

namespace Database\Seeders;

use App\Models\Product;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        User::updateOrCreate(
            ['email' => 'admin@example.com'],
            ['name' => 'Admin', 'password' => 'Password123!', 'role' => 'admin']
        );

        Product::firstOrCreate(
            ['name' => 'Sample Product'],
            ['description' => 'محصول نمونه برای آزمایش API', 'price' => 25.50, 'stock' => 100, 'is_active' => true]
        );
    }
}
