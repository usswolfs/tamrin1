<?php

use Illuminate\Support\Facades\Route;

Route::get('/', fn () => response()->json([
    'application' => 'Backend CRUD API',
    'status' => 'running',
    'api' => '/api',
]));
