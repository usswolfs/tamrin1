# Restaurant Backend API

پروژه Backend رستوران بر اساس نیازمندی‌های whiteboard و سبک پروژه‌های Laravel آقای حجت فضائلی (Sanctum Token Auth + Form Requests + REST API + Postman Collection).

## ویژگی‌ها

- **CRUD موجودی غذا (Foods)** با اعتبارسنجی درخواست و مدیریت موجودی
- **CRUD کاربران رستوران (Users)** با نقش‌های admin / manager / staff
- **CRUD سفارش‌ها (Orders)** همراه با آیتم‌های سفارش و کاهش/بازگردانی موجودی
- **Request Validation** کامل با Form Requests و پیام‌های فارسی
- **Resource Allocation** و مدیریت موجودی در سطح تراکنش (DB Transaction)
- **احراز هویت با Token** (Laravel Sanctum)
- **Postman Collection** آماده

## پیش‌نیازها

- PHP >= 8.2
- Composer
- SQLite (پیش‌فرض) یا MySQL

## نصب و راه‌اندازی

```bash
composer install
cp .env.example .env
php artisan key:generate
php artisan migrate --seed
php artisan serve
```

API در آدرس زیر در دسترس است:

```
http://localhost:8000/api/v1
```

## کاربران نمونه (پس از seeder)

| ایمیل | رمز | نقش |
|-------|-----|-----|
| admin@restaurant.test | password | admin |
| manager@restaurant.test | password | manager |
| staff@restaurant.test | password | staff |

## Endpoints

### Auth
- `POST /api/v1/login` – ورود و دریافت Token
- `POST /api/v1/logout` – خروج (نیاز به Token)
- `GET  /api/v1/me` – اطلاعات کاربر جاری

### Foods (موجودی / غذا)
- `GET    /api/v1/foods`
- `POST   /api/v1/foods`
- `GET    /api/v1/foods/{id}`
- `PUT    /api/v1/foods/{id}`
- `DELETE /api/v1/foods/{id}`

### Users (کاربران رستوران)
- `GET    /api/v1/users`
- `POST   /api/v1/users`
- `GET    /api/v1/users/{id}`
- `PUT    /api/v1/users/{id}`
- `DELETE /api/v1/users/{id}`

### Orders (سفارش‌ها)
- `GET    /api/v1/orders`
- `POST   /api/v1/orders`
- `GET    /api/v1/orders/{id}`
- `PUT    /api/v1/orders/{id}`
- `DELETE /api/v1/orders/{id}`

همه روت‌های بالا (به جز login) نیاز به هدر زیر دارند:

```
Authorization: Bearer {token}
```

## Postman

فایل کالکشن در مسیر زیر قرار دارد:

```
postman/Restaurant_Backend_API.postman_collection.json
```

پس از Import، متغیر `base_url` را تنظیم کنید و با درخواست Login توکن به صورت خودکار در متغیر `token` ذخیره می‌شود.

## ساختار پروژه (الهام‌گرفته از سبک پروژه‌های شما)

- `app/Http/Controllers` – کنترلرهای Resource
- `app/Http/Requests` – اعتبارسنجی درخواست‌ها
- `app/Models` – مدل‌های Eloquent
- `routes/api.php` – روت‌های نسخه‌بندی‌شده (`/api/v1`)
- `database/migrations` + `seeders`
- `postman/` – کالکشن آماده

## نکات پیاده‌سازی مطابق whiteboard

1. **CRUD برای موجودی - غذا** → `FoodController` + validation + مدیریت stock
2. **CRUD برای کاربران رستوران** → `UserController` با نقش‌ها
3. **CRUD برای سفارش‌های رستوران** → `OrderController` با items و تراکنش
4. **Request Validation** → همه Store/Update از Form Request استفاده می‌کنند
5. **Resource Allocation** → کاهش/بازگردانی موجودی داخل `DB::transaction`
6. **اجرای CRUD با Token هویت‌سنجی‌شده** → Middleware `auth:sanctum`
7. **فایل Postman** → ارائه شده است

موفق باشید.
