<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreFoodRequest;
use App\Http\Requests\UpdateFoodRequest;
use App\Models\Food;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class FoodController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = Food::query();

        if ($request->has('category')) {
            $query->where('category', $request->category);
        }

        if ($request->has('is_available')) {
            $query->where('is_available', filter_var($request->is_available, FILTER_VALIDATE_BOOLEAN));
        }

        if ($request->has('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        $foods = $query->orderBy('name')->paginate($request->get('per_page', 15));

        return response()->json($foods);
    }

    public function store(StoreFoodRequest $request): JsonResponse
    {
        $food = Food::create($request->validated());

        return response()->json([
            'message' => 'غذا با موفقیت ایجاد شد.',
            'data' => $food,
        ], 201);
    }

    public function show(Food $food): JsonResponse
    {
        return response()->json([
            'data' => $food,
        ]);
    }

    public function update(UpdateFoodRequest $request, Food $food): JsonResponse
    {
        $food->update($request->validated());

        return response()->json([
            'message' => 'غذا با موفقیت به‌روزرسانی شد.',
            'data' => $food->fresh(),
        ]);
    }

    public function destroy(Food $food): JsonResponse
    {
        $food->delete();

        return response()->json([
            'message' => 'غذا با موفقیت حذف شد.',
        ]);
    }
}
