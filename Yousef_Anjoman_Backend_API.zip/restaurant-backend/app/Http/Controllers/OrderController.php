<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreOrderRequest;
use App\Http\Requests\UpdateOrderRequest;
use App\Models\Food;
use App\Models\Order;
use App\Models\OrderItem;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = Order::with(['items.food', 'user']);

        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        if ($request->has('user_id')) {
            $query->where('user_id', $request->user_id);
        }

        $orders = $query->orderByDesc('created_at')->paginate($request->get('per_page', 15));

        return response()->json($orders);
    }

    public function store(StoreOrderRequest $request): JsonResponse
    {
        $order = DB::transaction(function () use ($request) {
            $total = 0;
            $itemsData = [];

            foreach ($request->items as $item) {
                $food = Food::findOrFail($item['food_id']);

                if (!$food->is_available) {
                    abort(422, "غذای «{$food->name}» در حال حاضر موجود نیست.");
                }

                if ($food->stock < $item['quantity']) {
                    abort(422, "موجودی غذای «{$food->name}» کافی نیست. موجودی: {$food->stock}");
                }

                $subtotal = $food->price * $item['quantity'];
                $total += $subtotal;

                $itemsData[] = [
                    'food' => $food,
                    'quantity' => $item['quantity'],
                    'unit_price' => $food->price,
                    'subtotal' => $subtotal,
                ];
            }

            $order = Order::create([
                'user_id' => $request->user()?->id,
                'customer_name' => $request->customer_name,
                'customer_phone' => $request->customer_phone,
                'table_number' => $request->table_number,
                'status' => 'pending',
                'total_price' => $total,
                'notes' => $request->notes,
            ]);

            foreach ($itemsData as $itemData) {
                OrderItem::create([
                    'order_id' => $order->id,
                    'food_id' => $itemData['food']->id,
                    'quantity' => $itemData['quantity'],
                    'unit_price' => $itemData['unit_price'],
                    'subtotal' => $itemData['subtotal'],
                ]);

                // کاهش موجودی
                $itemData['food']->decrement('stock', $itemData['quantity']);
            }

            return $order->load(['items.food', 'user']);
        });

        return response()->json([
            'message' => 'سفارش با موفقیت ثبت شد.',
            'data' => $order,
        ], 201);
    }

    public function show(Order $order): JsonResponse
    {
        $order->load(['items.food', 'user']);

        return response()->json([
            'data' => $order,
        ]);
    }

    public function update(UpdateOrderRequest $request, Order $order): JsonResponse
    {
        $order = DB::transaction(function () use ($request, $order) {
            $data = $request->only(['customer_name', 'customer_phone', 'table_number', 'status', 'notes']);

            if ($request->has('items')) {
                // بازگرداندن موجودی قبلی
                foreach ($order->items as $oldItem) {
                    $oldItem->food->increment('stock', $oldItem->quantity);
                }
                $order->items()->delete();

                $total = 0;
                foreach ($request->items as $item) {
                    $food = Food::findOrFail($item['food_id']);

                    if ($food->stock < $item['quantity']) {
                        abort(422, "موجودی غذای «{$food->name}» کافی نیست.");
                    }

                    $subtotal = $food->price * $item['quantity'];
                    $total += $subtotal;

                    OrderItem::create([
                        'order_id' => $order->id,
                        'food_id' => $food->id,
                        'quantity' => $item['quantity'],
                        'unit_price' => $food->price,
                        'subtotal' => $subtotal,
                    ]);

                    $food->decrement('stock', $item['quantity']);
                }

                $data['total_price'] = $total;
            }

            $order->update($data);

            return $order->fresh()->load(['items.food', 'user']);
        });

        return response()->json([
            'message' => 'سفارش با موفقیت به‌روزرسانی شد.',
            'data' => $order,
        ]);
    }

    public function destroy(Order $order): JsonResponse
    {
        DB::transaction(function () use ($order) {
            // بازگرداندن موجودی
            foreach ($order->items as $item) {
                $item->food->increment('stock', $item->quantity);
            }
            $order->delete();
        });

        return response()->json([
            'message' => 'سفارش با موفقیت حذف شد.',
        ]);
    }
}
