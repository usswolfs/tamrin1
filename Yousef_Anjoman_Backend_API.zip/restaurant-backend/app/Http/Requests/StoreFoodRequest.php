<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreFoodRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'price' => 'required|numeric|min:0',
            'category' => 'nullable|string|in:appetizer,main,dessert,drink',
            'stock' => 'required|integer|min:0',
            'is_available' => 'boolean',
            'image' => 'nullable|string|max:500',
        ];
    }

    public function messages(): array
    {
        return [
            'name.required' => 'نام غذا الزامی است.',
            'price.required' => 'قیمت الزامی است.',
            'price.numeric' => 'قیمت باید عدد باشد.',
            'stock.required' => 'موجودی الزامی است.',
        ];
    }
}
