<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreOrderRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'customer_name' => 'required|string|max:255',
            'customer_phone' => 'nullable|string|max:20',
            'table_number' => 'nullable|string|max:20',
            'notes' => 'nullable|string',
            'items' => 'required|array|min:1',
            'items.*.food_id' => 'required|exists:foods,id',
            'items.*.quantity' => 'required|integer|min:1',
        ];
    }

    public function messages(): array
    {
        return [
            'customer_name.required' => 'نام مشتری الزامی است.',
            'items.required' => 'حداقل یک آیتم سفارش لازم است.',
            'items.*.food_id.exists' => 'غذای انتخاب شده وجود ندارد.',
            'items.*.quantity.min' => 'تعداد باید حداقل ۱ باشد.',
        ];
    }
}
