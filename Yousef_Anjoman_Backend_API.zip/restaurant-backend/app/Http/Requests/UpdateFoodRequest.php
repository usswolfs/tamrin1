<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateFoodRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => 'sometimes|string|max:255',
            'description' => 'nullable|string',
            'price' => 'sometimes|numeric|min:0',
            'category' => 'nullable|string|in:appetizer,main,dessert,drink',
            'stock' => 'sometimes|integer|min:0',
            'is_available' => 'boolean',
            'image' => 'nullable|string|max:500',
        ];
    }
}
