<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Password;

class UpdateUserRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => 'sometimes|string|max:255',
            'email' => [
                'sometimes',
                'email',
                Rule::unique('users')->ignore($this->route('user')),
            ],
            'password' => ['sometimes', 'confirmed', Password::defaults()],
            'role' => 'sometimes|in:admin,manager,staff',
            'phone' => 'nullable|string|max:20',
            'is_active' => 'boolean',
        ];
    }
}
