<?php

namespace Database\Seeders;

use App\Models\Food;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Admin user
        User::create([
            'name' => 'مدیر رستوران',
            'email' => 'admin@restaurant.test',
            'password' => Hash::make('password'),
            'role' => 'admin',
            'phone' => '09120000000',
            'is_active' => true,
        ]);

        // Manager
        User::create([
            'name' => 'مدیر سالن',
            'email' => 'manager@restaurant.test',
            'password' => Hash::make('password'),
            'role' => 'manager',
            'phone' => '09121111111',
            'is_active' => true,
        ]);

        // Staff
        User::create([
            'name' => 'گارسون',
            'email' => 'staff@restaurant.test',
            'password' => Hash::make('password'),
            'role' => 'staff',
            'phone' => '09122222222',
            'is_active' => true,
        ]);

        // Sample foods
        $foods = [
            ['name' => 'چلو کباب کوبیده', 'description' => 'دو سیخ کباب کوبیده با برنج و گوجه', 'price' => 280000, 'category' => 'main', 'stock' => 50],
            ['name' => 'چلو جوجه کباب', 'description' => 'جوجه کباب با برنج ایرانی', 'price' => 320000, 'category' => 'main', 'stock' => 40],
            ['name' => 'سالاد سزار', 'description' => 'سالاد سزار با سس مخصوص', 'price' => 95000, 'category' => 'appetizer', 'stock' => 30],
            ['name' => 'سوپ جو', 'description' => 'سوپ جو با مرغ', 'price' => 75000, 'category' => 'appetizer', 'stock' => 25],
            ['name' => 'بستنی وانیلی', 'description' => 'دو اسکوپ بستنی وانیلی', 'price' => 45000, 'category' => 'dessert', 'stock' => 60],
            ['name' => 'نوشابه', 'description' => 'نوشابه گازدار ۳۳۰ میلی‌لیتر', 'price' => 25000, 'category' => 'drink', 'stock' => 100],
            ['name' => 'دوغ', 'description' => 'دوغ محلی', 'price' => 20000, 'category' => 'drink', 'stock' => 80],
            ['name' => 'چلو قیمه', 'description' => 'قیمه با برنج و خلال بادام', 'price' => 250000, 'category' => 'main', 'stock' => 35],
        ];

        foreach ($foods as $food) {
            Food::create(array_merge($food, ['is_available' => true]));
        }
    }
}
