<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\FoodController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes - Restaurant Backend
|--------------------------------------------------------------------------
|
| همه روت‌های CRUD با Middleware احراز هویت Token (Sanctum) محافظت شده‌اند.
| Request Validation با Form Requests انجام می‌شود.
|
*/

Route::prefix('v1')->group(function () {

    // Auth (عمومی)
    Route::post('/login', [AuthController::class, 'login']);

    // Protected routes
    Route::middleware('auth:sanctum')->group(function () {

        Route::post('/logout', [AuthController::class, 'logout']);
        Route::get('/me', [AuthController::class, 'me']);

        // CRUD Foods (موجودی / غذا)
        Route::apiResource('foods', FoodController::class);

        // CRUD Users (کاربران رستوران)
        Route::apiResource('users', UserController::class);

        // CRUD Orders (سفارش‌های رستوران)
        Route::apiResource('orders', OrderController::class);
    });
});
