<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Http\Requests\StoreFoodRequest;
use App\Http\Requests\UpdateFoodRequest;
use App\Http\Resources\FoodResource;
use App\Models\Food;

class FoodController extends Controller
{
    public function index() { return FoodResource::collection(Food::with('restaurant')->paginate(15)); }
    public function store(StoreFoodRequest $request) {
        return new FoodResource(Food::create($request->validated())->load('restaurant'));
    }
    public function show(Food $food) { return new FoodResource($food->load('restaurant')); }
    public function update(UpdateFoodRequest $request, Food $food) {
        $food->update($request->validated());
        return new FoodResource($food->load('restaurant'));
    }
    public function destroy(Food $food) {
        $food->delete();
        return response()->json(['message' => 'Food deleted successfully']);
    }
}
