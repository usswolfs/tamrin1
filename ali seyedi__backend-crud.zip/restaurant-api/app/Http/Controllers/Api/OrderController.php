<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Http\Requests\StoreOrderRequest;
use App\Http\Requests\UpdateOrderRequest;
use App\Http\Resources\OrderResource;
use App\Models\Food;
use App\Models\Order;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class OrderController extends Controller
{
    public function index() {
        return OrderResource::collection(Order::with(['restaurant', 'foods'])->latest()->paginate(15));
    }

    public function store(StoreOrderRequest $request) {
        $data = $request->validated();
        $order = DB::transaction(function () use ($data, $request) {
            $order = Order::create([
                'user_id' => $request->user()->id,
                'restaurant_id' => $data['restaurant_id'],
                'status' => $data['status'] ?? 'pending',
                'total_price' => 0,
            ]);
            $total = 0;
            foreach ($data['foods'] as $item) {
                $food = Food::findOrFail($item['id']);
                if ((int) $food->restaurant_id !== (int) $data['restaurant_id']) {
                    throw ValidationException::withMessages([
                        'foods' => ["Food #{$food->id} does not belong to the selected restaurant."],
                    ]);
                }
                $qty = (int) $item['quantity'];
                $order->foods()->attach($food->id, ['quantity' => $qty, 'unit_price' => $food->price]);
                $total += (float) $food->price * $qty;
            }
            $order->update(['total_price' => $total]);
            return $order;
        });
        return new OrderResource($order->load(['restaurant', 'foods']));
    }

    public function show(Order $order) { return new OrderResource($order->load(['restaurant', 'foods'])); }

    public function update(UpdateOrderRequest $request, Order $order) {
        $data = $request->validated();
        DB::transaction(function () use ($data, $order) {
            if (isset($data['status'])) $order->update(['status' => $data['status']]);
            if (isset($data['foods'])) {
                $order->foods()->detach();
                $total = 0;
                foreach ($data['foods'] as $item) {
                    $food = Food::findOrFail($item['id']);
                    if ((int) $food->restaurant_id !== (int) $order->restaurant_id) {
                        throw ValidationException::withMessages([
                            'foods' => ["Food #{$food->id} does not belong to this order's restaurant."],
                        ]);
                    }
                    $qty = (int) $item['quantity'];
                    $order->foods()->attach($food->id, ['quantity' => $qty, 'unit_price' => $food->price]);
                    $total += (float) $food->price * $qty;
                }
                $order->update(['total_price' => $total]);
            }
        });
        return new OrderResource($order->fresh()->load(['restaurant', 'foods']));
    }

    public function destroy(Order $order) {
        $order->delete();
        return response()->json(['message' => 'Order deleted successfully']);
    }
}
