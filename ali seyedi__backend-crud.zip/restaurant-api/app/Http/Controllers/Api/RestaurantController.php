<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Http\Requests\StoreRestaurantRequest;
use App\Http\Requests\UpdateRestaurantRequest;
use App\Http\Resources\RestaurantResource;
use App\Models\Restaurant;

class RestaurantController extends Controller
{
    public function index() { return RestaurantResource::collection(Restaurant::paginate(15)); }
    public function store(StoreRestaurantRequest $request) {
        return new RestaurantResource(Restaurant::create($request->validated()));
    }
    public function show(Restaurant $restaurant) {
        return new RestaurantResource($restaurant->load('foods'));
    }
    public function update(UpdateRestaurantRequest $request, Restaurant $restaurant) {
        $restaurant->update($request->validated());
        return new RestaurantResource($restaurant);
    }
    public function destroy(Restaurant $restaurant) {
        $restaurant->delete();
        return response()->json(['message' => 'Restaurant deleted successfully']);
    }
}
