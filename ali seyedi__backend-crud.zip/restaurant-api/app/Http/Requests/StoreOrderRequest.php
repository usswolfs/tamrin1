<?php
namespace App\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;

class StoreOrderRequest extends FormRequest
{
    public function authorize(): bool { return true; }
    public function rules(): array {
        return [
            'restaurant_id' => ['required', 'exists:restaurants,id'],
            'status' => ['nullable', 'in:pending,preparing,completed,cancelled'],
            'foods' => ['required', 'array', 'min:1'],
            'foods.*.id' => ['required', 'exists:foods,id'],
            'foods.*.quantity' => ['required', 'integer', 'min:1'],
        ];
    }
}
