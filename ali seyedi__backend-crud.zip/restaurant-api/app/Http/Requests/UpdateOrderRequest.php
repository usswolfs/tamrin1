<?php
namespace App\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;

class UpdateOrderRequest extends FormRequest
{
    public function authorize(): bool { return true; }
    public function rules(): array {
        return [
            'status' => ['sometimes', 'required', 'in:pending,preparing,completed,cancelled'],
            'foods' => ['sometimes', 'array', 'min:1'],
            'foods.*.id' => ['required_with:foods', 'exists:foods,id'],
            'foods.*.quantity' => ['required_with:foods', 'integer', 'min:1'],
        ];
    }
}
