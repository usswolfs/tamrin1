<?php
namespace App\Http\Resources;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class OrderResource extends JsonResource
{
    public function toArray(Request $request): array {
        return [
            'id' => $this->id,
            'status' => $this->status,
            'total_price' => $this->total_price,
            'restaurant' => new RestaurantResource($this->whenLoaded('restaurant')),
            'foods' => $this->whenLoaded('foods', fn () => $this->foods->map(fn ($food) => [
                'id' => $food->id,
                'name' => $food->name,
                'price' => $food->price,
                'quantity' => $food->pivot->quantity,
                'unit_price' => $food->pivot->unit_price,
            ])),
            'created_at' => $this->created_at?->toDateTimeString(),
        ];
    }
}
