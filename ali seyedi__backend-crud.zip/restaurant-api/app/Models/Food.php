<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Food extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'description', 'price', 'restaurant_id'];
    protected $casts = ['price' => 'decimal:2'];

    public function restaurant() { return $this->belongsTo(Restaurant::class); }
    public function orders() {
        return $this->belongsToMany(Order::class, 'order_food')
            ->withPivot('quantity', 'unit_price')->withTimestamps();
    }
}
