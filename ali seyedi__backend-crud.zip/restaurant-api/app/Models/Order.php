<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    protected $fillable = ['user_id', 'restaurant_id', 'status', 'total_price'];
    protected $casts = ['total_price' => 'decimal:2'];

    public function user() { return $this->belongsTo(User::class); }
    public function restaurant() { return $this->belongsTo(Restaurant::class); }
    public function foods() {
        return $this->belongsToMany(Food::class, 'order_food')
            ->withPivot('quantity', 'unit_price')->withTimestamps();
    }
}
