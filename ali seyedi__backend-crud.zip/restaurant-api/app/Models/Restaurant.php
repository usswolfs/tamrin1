<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Restaurant extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'address', 'phone'];

    public function foods() { return $this->hasMany(Food::class); }
    public function orders() { return $this->hasMany(Order::class); }
}
