#!/usr/bin/env bash
set -euo pipefail

# بررسی درایور SQLite
php -m | grep -q 'pdo_sqlite' || { echo "php-sqlite3 نصب نیست. اجرا کن: sudo apt install -y php-sqlite3"; exit 1; }

# تنظیم .env
grep -q '^DB_CONNECTION=' .env && sed -i 's/^DB_CONNECTION=.*/DB_CONNECTION=sqlite/' .env || echo 'DB_CONNECTION=sqlite' >> .env
grep -q '^SESSION_DRIVER=' .env && sed -i 's/^SESSION_DRIVER=.*/SESSION_DRIVER=file/' .env || echo 'SESSION_DRIVER=file' >> .env
touch database/database.sqlite

mkdir -p app/Http/Controllers/Api app/Http/Requests app/Http/Resources database/seeders postman

echo "==> ساخت مایگریشن‌ها"
cat > database/migrations/2026_01_01_000001_create_restaurants_table.php <<'PHP'
<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('restaurants', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('address');
            $table->string('phone')->nullable();
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('restaurants'); }
};
PHP

cat > database/migrations/2026_01_01_000002_create_foods_table.php <<'PHP'
<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('foods', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->text('description')->nullable();
            $table->decimal('price', 10, 2);
            $table->foreignId('restaurant_id')->constrained()->cascadeOnDelete();
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('foods'); }
};
PHP

cat > database/migrations/2026_01_01_000003_create_orders_table.php <<'PHP'
<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('restaurant_id')->constrained()->cascadeOnDelete();
            $table->string('status')->default('pending');
            $table->decimal('total_price', 12, 2)->default(0);
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('orders'); }
};
PHP

cat > database/migrations/2026_01_01_000004_create_order_food_table.php <<'PHP'
<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('order_food', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained()->cascadeOnDelete();
            $table->foreignId('food_id')->constrained()->cascadeOnDelete();
            $table->unsignedInteger('quantity')->default(1);
            $table->decimal('unit_price', 10, 2);
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('order_food'); }
};
PHP

echo "==> ساخت مدل‌ها"
cat > app/Models/User.php <<'PHP'
<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $fillable = ['name', 'email', 'password'];
    protected $hidden = ['password', 'remember_token'];
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];
}
PHP

cat > app/Models/Restaurant.php <<'PHP'
<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Restaurant extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'address', 'phone'];

    public function foods() { return $this->hasMany(Food::class); }
    public function orders() { return $this->hasMany(Order::class); }
}
PHP

cat > app/Models/Food.php <<'PHP'
<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Food extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'description', 'price', 'restaurant_id'];
    protected $casts = ['price' => 'decimal:2'];

    public function restaurant() { return $this->belongsTo(Restaurant::class); }
    public function orders() {
        return $this->belongsToMany(Order::class, 'order_food')
            ->withPivot('quantity', 'unit_price')->withTimestamps();
    }
}
PHP

cat > app/Models/Order.php <<'PHP'
<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    protected $fillable = ['user_id', 'restaurant_id', 'status', 'total_price'];
    protected $casts = ['total_price' => 'decimal:2'];

    public function user() { return $this->belongsTo(User::class); }
    public function restaurant() { return $this->belongsTo(Restaurant::class); }
    public function foods() {
        return $this->belongsToMany(Food::class, 'order_food')
            ->withPivot('quantity', 'unit_price')->withTimestamps();
    }
}
PHP

echo "==> ساخت Form Requestها"
cat > app/Http/Requests/StoreFoodRequest.php <<'PHP'
<?php
namespace App\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;

class StoreFoodRequest extends FormRequest
{
    public function authorize(): bool { return true; }
    public function rules(): array {
        return [
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'price' => ['required', 'numeric', 'min:0'],
            'restaurant_id' => ['required', 'exists:restaurants,id'],
        ];
    }
}
PHP

cat > app/Http/Requests/UpdateFoodRequest.php <<'PHP'
<?php
namespace App\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;

class UpdateFoodRequest extends FormRequest
{
    public function authorize(): bool { return true; }
    public function rules(): array {
        return [
            'name' => ['sometimes', 'required', 'string', 'max:255'],
            'description' => ['sometimes', 'nullable', 'string'],
            'price' => ['sometimes', 'required', 'numeric', 'min:0'],
            'restaurant_id' => ['sometimes', 'required', 'exists:restaurants,id'],
        ];
    }
}
PHP

cat > app/Http/Requests/StoreRestaurantRequest.php <<'PHP'
<?php
namespace App\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;

class StoreRestaurantRequest extends FormRequest
{
    public function authorize(): bool { return true; }
    public function rules(): array {
        return [
            'name' => ['required', 'string', 'max:255'],
            'address' => ['required', 'string', 'max:255'],
            'phone' => ['nullable', 'string', 'max:30'],
        ];
    }
}
PHP

cat > app/Http/Requests/UpdateRestaurantRequest.php <<'PHP'
<?php
namespace App\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;

class UpdateRestaurantRequest extends FormRequest
{
    public function authorize(): bool { return true; }
    public function rules(): array {
        return [
            'name' => ['sometimes', 'required', 'string', 'max:255'],
            'address' => ['sometimes', 'required', 'string', 'max:255'],
            'phone' => ['sometimes', 'nullable', 'string', 'max:30'],
        ];
    }
}
PHP

cat > app/Http/Requests/StoreOrderRequest.php <<'PHP'
<?php
namespace App\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;

class StoreOrderRequest extends FormRequest
{
    public function authorize(): bool { return true; }
    public function rules(): array {
        return [
            'restaurant_id' => ['required', 'exists:restaurants,id'],
            'status' => ['nullable', 'in:pending,preparing,completed,cancelled'],
            'foods' => ['required', 'array', 'min:1'],
            'foods.*.id' => ['required', 'exists:foods,id'],
            'foods.*.quantity' => ['required', 'integer', 'min:1'],
        ];
    }
}
PHP

cat > app/Http/Requests/UpdateOrderRequest.php <<'PHP'
<?php
namespace App\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;

class UpdateOrderRequest extends FormRequest
{
    public function authorize(): bool { return true; }
    public function rules(): array {
        return [
            'status' => ['sometimes', 'required', 'in:pending,preparing,completed,cancelled'],
            'foods' => ['sometimes', 'array', 'min:1'],
            'foods.*.id' => ['required_with:foods', 'exists:foods,id'],
            'foods.*.quantity' => ['required_with:foods', 'integer', 'min:1'],
        ];
    }
}
PHP

echo "==> ساخت API Resourceها"
cat > app/Http/Resources/RestaurantResource.php <<'PHP'
<?php
namespace App\Http\Resources;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class RestaurantResource extends JsonResource
{
    public function toArray(Request $request): array {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'address' => $this->address,
            'phone' => $this->phone,
            'foods' => FoodResource::collection($this->whenLoaded('foods')),
            'created_at' => $this->created_at?->toDateTimeString(),
        ];
    }
}
PHP

cat > app/Http/Resources/FoodResource.php <<'PHP'
<?php
namespace App\Http\Resources;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class FoodResource extends JsonResource
{
    public function toArray(Request $request): array {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'description' => $this->description,
            'price' => $this->price,
            'restaurant' => new RestaurantResource($this->whenLoaded('restaurant')),
            'created_at' => $this->created_at?->toDateTimeString(),
        ];
    }
}
PHP

cat > app/Http/Resources/OrderResource.php <<'PHP'
<?php
namespace App\Http\Resources;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class OrderResource extends JsonResource
{
    public function toArray(Request $request): array {
        return [
            'id' => $this->id,
            'status' => $this->status,
            'total_price' => $this->total_price,
            'restaurant' => new RestaurantResource($this->whenLoaded('restaurant')),
            'foods' => $this->whenLoaded('foods', fn () => $this->foods->map(fn ($food) => [
                'id' => $food->id,
                'name' => $food->name,
                'price' => $food->price,
                'quantity' => $food->pivot->quantity,
                'unit_price' => $food->pivot->unit_price,
            ])),
            'created_at' => $this->created_at?->toDateTimeString(),
        ];
    }
}
PHP

echo "==> ساخت کنترلرها"
cat > app/Http/Controllers/Api/AuthController.php <<'PHP'
<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $data = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'string'],
        ]);
        if (!Auth::attempt($data)) {
            return response()->json(['message' => 'Invalid credentials'], 401);
        }
        $token = $request->user()->createToken('api-token')->plainTextToken;
        return response()->json(['token' => $token]);
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()?->delete();
        return response()->json(['message' => 'Logged out']);
    }
}
PHP

cat > app/Http/Controllers/Api/RestaurantController.php <<'PHP'
<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Http\Requests\StoreRestaurantRequest;
use App\Http\Requests\UpdateRestaurantRequest;
use App\Http\Resources\RestaurantResource;
use App\Models\Restaurant;

class RestaurantController extends Controller
{
    public function index() { return RestaurantResource::collection(Restaurant::paginate(15)); }
    public function store(StoreRestaurantRequest $request) {
        return new RestaurantResource(Restaurant::create($request->validated()));
    }
    public function show(Restaurant $restaurant) {
        return new RestaurantResource($restaurant->load('foods'));
    }
    public function update(UpdateRestaurantRequest $request, Restaurant $restaurant) {
        $restaurant->update($request->validated());
        return new RestaurantResource($restaurant);
    }
    public function destroy(Restaurant $restaurant) {
        $restaurant->delete();
        return response()->json(['message' => 'Restaurant deleted successfully']);
    }
}
PHP

cat > app/Http/Controllers/Api/FoodController.php <<'PHP'
<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Http\Requests\StoreFoodRequest;
use App\Http\Requests\UpdateFoodRequest;
use App\Http\Resources\FoodResource;
use App\Models\Food;

class FoodController extends Controller
{
    public function index() { return FoodResource::collection(Food::with('restaurant')->paginate(15)); }
    public function store(StoreFoodRequest $request) {
        return new FoodResource(Food::create($request->validated())->load('restaurant'));
    }
    public function show(Food $food) { return new FoodResource($food->load('restaurant')); }
    public function update(UpdateFoodRequest $request, Food $food) {
        $food->update($request->validated());
        return new FoodResource($food->load('restaurant'));
    }
    public function destroy(Food $food) {
        $food->delete();
        return response()->json(['message' => 'Food deleted successfully']);
    }
}
PHP

cat > app/Http/Controllers/Api/OrderController.php <<'PHP'
<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Http\Requests\StoreOrderRequest;
use App\Http\Requests\UpdateOrderRequest;
use App\Http\Resources\OrderResource;
use App\Models\Food;
use App\Models\Order;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class OrderController extends Controller
{
    public function index() {
        return OrderResource::collection(Order::with(['restaurant', 'foods'])->latest()->paginate(15));
    }

    public function store(StoreOrderRequest $request) {
        $data = $request->validated();
        $order = DB::transaction(function () use ($data, $request) {
            $order = Order::create([
                'user_id' => $request->user()->id,
                'restaurant_id' => $data['restaurant_id'],
                'status' => $data['status'] ?? 'pending',
                'total_price' => 0,
            ]);
            $total = 0;
            foreach ($data['foods'] as $item) {
                $food = Food::findOrFail($item['id']);
                if ((int) $food->restaurant_id !== (int) $data['restaurant_id']) {
                    throw ValidationException::withMessages([
                        'foods' => ["Food #{$food->id} does not belong to the selected restaurant."],
                    ]);
                }
                $qty = (int) $item['quantity'];
                $order->foods()->attach($food->id, ['quantity' => $qty, 'unit_price' => $food->price]);
                $total += (float) $food->price * $qty;
            }
            $order->update(['total_price' => $total]);
            return $order;
        });
        return new OrderResource($order->load(['restaurant', 'foods']));
    }

    public function show(Order $order) { return new OrderResource($order->load(['restaurant', 'foods'])); }

    public function update(UpdateOrderRequest $request, Order $order) {
        $data = $request->validated();
        DB::transaction(function () use ($data, $order) {
            if (isset($data['status'])) $order->update(['status' => $data['status']]);
            if (isset($data['foods'])) {
                $order->foods()->detach();
                $total = 0;
                foreach ($data['foods'] as $item) {
                    $food = Food::findOrFail($item['id']);
                    if ((int) $food->restaurant_id !== (int) $order->restaurant_id) {
                        throw ValidationException::withMessages([
                            'foods' => ["Food #{$food->id} does not belong to this order's restaurant."],
                        ]);
                    }
                    $qty = (int) $item['quantity'];
                    $order->foods()->attach($food->id, ['quantity' => $qty, 'unit_price' => $food->price]);
                    $total += (float) $food->price * $qty;
                }
                $order->update(['total_price' => $total]);
            }
        });
        return new OrderResource($order->fresh()->load(['restaurant', 'foods']));
    }

    public function destroy(Order $order) {
        $order->delete();
        return response()->json(['message' => 'Order deleted successfully']);
    }
}
PHP

echo "==> تعریف مسیرها"
cat > routes/api.php <<'PHP'
<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\FoodController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\RestaurantController;
use Illuminate\Support\Facades\Route;

Route::post('/login', [AuthController::class, 'login']);

Route::middleware('auth:sanctum')->group(function () {
    Route::apiResource('foods', FoodController::class);
    Route::apiResource('restaurants', RestaurantController::class);
    Route::apiResource('orders', OrderController::class);
    Route::post('/logout', [AuthController::class, 'logout']);
});
PHP

echo "==> ساخت Seeder"
cat > database/seeders/DatabaseSeeder.php <<'PHP'
<?php
namespace Database\Seeders;

use App\Models\Food;
use App\Models\Restaurant;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        User::firstOrCreate(
            ['email' => 'demo@example.com'],
            ['name' => 'Demo User', 'password' => Hash::make('password')]
        );
        $restaurant = Restaurant::firstOrCreate(
            ['name' => 'Demo Restaurant'],
            ['address' => 'Demo Street', 'phone' => '09120000000']
        );
        Food::firstOrCreate(
            ['name' => 'Pizza', 'restaurant_id' => $restaurant->id],
            ['description' => 'Cheese pizza', 'price' => 12.50]
        );
        Food::firstOrCreate(
            ['name' => 'Burger', 'restaurant_id' => $restaurant->id],
            ['description' => 'Beef burger', 'price' => 8.00]
        );
    }
}
PHP

echo "==> ساخت مجموعه Postman"
cat > postman/RestaurantApi.postman_collection.json <<'JSON'
{
  "info": {
    "name": "Restaurant API",
    "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
  },
  "variable": [
    { "key": "base_url", "value": "http://127.0.0.1:8000/api" },
    { "key": "token", "value": "" }
  ],
  "item": [
    {
      "name": "Auth",
      "item": [
        {
          "name": "Login",
          "request": {
            "method": "POST",
            "header": [{ "key": "Content-Type", "value": "application/json" }],
            "url": "{{base_url}}/login",
            "body": {
              "mode": "raw",
              "raw": "{\"email\":\"demo@example.com\",\"password\":\"password\"}"
            }
          },
          "event": [{
            "listen": "test",
            "script": { "exec": ["pm.collectionVariables.set('token', pm.response.json().token);"] }
          }]
        },
        {
          "name": "Logout",
          "request": {
            "method": "POST",
            "header": [{ "key": "Authorization", "value": "Bearer {{token}}" }],
            "url": "{{base_url}}/logout"
          }
        }
      ]
    },
    {
      "name": "Foods",
      "item": [
        { "name": "List Foods", "request": { "method": "GET", "header": [{ "key": "Authorization", "value": "Bearer {{token}}" }], "url": "{{base_url}}/foods" } },
        { "name": "Create Food", "request": { "method": "POST", "header": [{ "key": "Authorization", "value": "Bearer {{token}}" }, { "key": "Content-Type", "value": "application/json" }], "url": "{{base_url}}/foods", "body": { "mode": "raw", "raw": "{\"name\":\"Pizza\",\"description\":\"Cheese pizza\",\"price\":12.5,\"restaurant_id\":1}" } } },
        { "name": "Show Food", "request": { "method": "GET", "header": [{ "key": "Authorization", "value": "Bearer {{token}}" }], "url": "{{base_url}}/foods/1" } },
        { "name": "Update Food", "request": { "method": "PUT", "header": [{ "key": "Authorization", "value": "Bearer {{token}}" }, { "key": "Content-Type", "value": "application/json" }], "url": "{{base_url}}/foods/1", "body": { "mode": "raw", "raw": "{\"price\":14.0}" } } },
        { "name": "Delete Food", "request": { "method": "DELETE", "header": [{ "key": "Authorization", "value": "Bearer {{token}}" }], "url": "{{base_url}}/foods/1" } }
      ]
    },
    {
      "name": "Restaurants",
      "item": [
        { "name": "List Restaurants", "request": { "method": "GET", "header": [{ "key": "Authorization", "value": "Bearer {{token}}" }], "url": "{{base_url}}/restaurants" } },
        { "name": "Create Restaurant", "request": { "method": "POST", "header": [{ "key": "Authorization", "value": "Bearer {{token}}" }, { "key": "Content-Type", "value": "application/json" }], "url": "{{base_url}}/restaurants", "body": { "mode": "raw", "raw": "{\"name\":\"Demo Restaurant\",\"address\":\"Demo Street\",\"phone\":\"09120000000\"}" } } },
        { "name": "Show Restaurant", "request": { "method": "GET", "header": [{ "key": "Authorization", "value": "Bearer {{token}}" }], "url": "{{base_url}}/restaurants/1" } },
        { "name": "Update Restaurant", "request": { "method": "PUT", "header": [{ "key": "Authorization", "value": "Bearer {{token}}" }, { "key": "Content-Type", "value": "application/json" }], "url": "{{base_url}}/restaurants/1", "body": { "mode": "raw", "raw": "{\"phone\":\"09121111111\"}" } } },
        { "name": "Delete Restaurant", "request": { "method": "DELETE", "header": [{ "key": "Authorization", "value": "Bearer {{token}}" }], "url": "{{base_url}}/restaurants/1" } }
      ]
    },
    {
      "name": "Orders",
      "item": [
        { "name": "List Orders", "request": { "method": "GET", "header": [{ "key": "Authorization", "value": "Bearer {{token}}" }], "url": "{{base_url}}/orders" } },
        { "name": "Create Order", "request": { "method": "POST", "header": [{ "key": "Authorization", "value": "Bearer {{token}}" }, { "key": "Content-Type", "value": "application/json" }], "url": "{{base_url}}/orders", "body": { "mode": "raw", "raw": "{\"restaurant_id\":1,\"status\":\"pending\",\"foods\":[{\"id\":1,\"quantity\":2}]}" } } },
        { "name": "Show Order", "request": { "method": "GET", "header": [{ "key": "Authorization", "value": "Bearer {{token}}" }], "url": "{{base_url}}/orders/1" } },
        { "name": "Update Order", "request": { "method": "PUT", "header": [{ "key": "Authorization", "value": "Bearer {{token}}" }, { "key": "Content-Type", "value": "application/json" }], "url": "{{base_url}}/orders/1", "body": { "mode": "raw", "raw": "{\"status\":\"completed\",\"foods\":[{\"id\":1,\"quantity\":3}]}" } } },
        { "name": "Delete Order", "request": { "method": "DELETE", "header": [{ "key": "Authorization", "value": "Bearer {{token}}" }], "url": "{{base_url}}/orders/1" } }
      ]
    }
  ]
}
JSON

echo "==> اجرای مایگریشن و Seeder"
php artisan optimize:clear
php artisan migrate:fresh --seed --force

echo ""
echo "✅ پروژه کامل شد."
echo "اجرای سرور:  php artisan serve --host=0.0.0.0 --port=8000"
echo "اطلاعات ورود: demo@example.com / password"
echo "فایل Postman: postman/RestaurantApi.postman_collection.json"
