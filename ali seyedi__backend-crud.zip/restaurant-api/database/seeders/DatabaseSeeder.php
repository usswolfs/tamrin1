<?php
namespace Database\Seeders;

use App\Models\Food;
use App\Models\Restaurant;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        User::firstOrCreate(
            ['email' => 'demo@example.com'],
            ['name' => 'Demo User', 'password' => Hash::make('password')]
        );
        $restaurant = Restaurant::firstOrCreate(
            ['name' => 'Demo Restaurant'],
            ['address' => 'Demo Street', 'phone' => '09120000000']
        );
        Food::firstOrCreate(
            ['name' => 'Pizza', 'restaurant_id' => $restaurant->id],
            ['description' => 'Cheese pizza', 'price' => 12.50]
        );
        Food::firstOrCreate(
            ['name' => 'Burger', 'restaurant_id' => $restaurant->id],
            ['description' => 'Beef burger', 'price' => 8.00]
        );
    }
}
